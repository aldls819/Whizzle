// export const BASE_URL = "https://j8a805.p.ssafy.io:8080";  // 배포용
export const BASE_URL = "http://j8a805.p.ssafy.io:8080"; // 테스트용
// export const BASE_URL = "http://localhost:8080"; // 로컬 테스트용

export const LOCAL_FRONT_URL = "http://localhost:3000"; // 로컬 프론트

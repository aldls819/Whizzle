import React from "react";

//메인 화면에 띄워줄 추천 위스키 리스트(로그인 사용자)
const MainWhiskyList = () => {
  return <>{/* <h1>로그인 사용자에게 위스키 추천</h1> */}</>;
};

export default MainWhiskyList;

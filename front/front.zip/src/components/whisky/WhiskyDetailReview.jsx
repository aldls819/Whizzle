import React from "react";

//위스키 상세페이지에 띄워줄 해당 위스키의 리뷰목록
const WhiskyDetailReview = () => {
  return (
    <>
      <h1>해당 위스키에 대한 리뷰들</h1>
    </>
  );
};

export default WhiskyDetailReview;

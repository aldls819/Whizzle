import { atom, selector } from "recoil";

export const diaryState = atom({
  key: "diaryState",
  default: {},
});
